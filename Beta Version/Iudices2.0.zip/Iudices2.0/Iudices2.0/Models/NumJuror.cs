﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Iudices2._0.Models
{
    public class NumJuror
{
        public int numberOfJurors { get; set; }
}
}
