﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Iudices2._0.Models
{
    public class Juror
    {
        public int ID;

        public string firstName;

        public string lastName;

        public string streetAddress;

        public string city;

        public string state;

        public int zipcode;
    }
}
